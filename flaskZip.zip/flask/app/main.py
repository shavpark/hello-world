# https://flask.palletsprojects.com/en/2.0.x/cli/
# export FLASK_APP=app.py / Windows: set FLASK_APP=app.py
# export FLASK_ENV=development/Windows: set FLASK_ENV=development
# flask run / Windows: python -m flask run
from flask import Flask, render_template, request
# import sqlite3  # sqlite3.connect()
import os, sys  
currentdir = os.path.dirname(os.path.realpath(__file__))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
from function import config # import function from custom module
import pandas as pd

# create an instance of Flask object
app = Flask(__name__)

import requests
headers = {'Content-type':"application/json"}    
session = requests.Session()
session.headers.update(headers)

db_file = os.path.join("Train Project.db")
db = config.sqlalchemy_sqlite3(db_file)

@app.route('/')
def home():
    heading = "Train Schedule API"
    return render_template('index.html', heading=f'{heading}')

@app.route('/list_train', methods=['GET','POST'])
def list_train():
    resultset = db.execute("SELECT * FROM TrainSchedule") 
    rows = resultset.fetchall() #list of tuples
    df = pd.read_sql("SELECT * FROM TrainSchedule", db) #dataframe
    return render_template(
        'index_api.html',
        heading="List of Trains",
       # raw = f'raw:{rows}',
        dataframe = df.to_html())

@app.route('/list_train_from', methods=['POST'])
def list_train_from():
    data = {
        "Origin": request.form['input_string']
    }
    df = pd.read_sql("SELECT * FROM TrainSchedule WHERE origin like :Origin", db, params=data)
    return render_template(
        'index_api.html',
        heading=f"Departure train from {data['Origin']}",
        dataframe = df.to_html())

if __name__ == "__main__":
    app.run(debug=True)